import { StyleSheet, View } from 'react-native';
import { ActivityIndicator, Text } from 'react-native-paper';
import BotaoGrande from './BotaoGrande';
import { cores, espacos, tipografia } from '../config/theme';

// Tela cheia mostrada enquanto os dados vêm do Firebase.
// Se a busca falhar, mostra o erro com o botão para tentar de novo.
export default function TelaCarregando({ erro, onTentarNovamente }) {
  return (
    <View style={styles.tela}>
      {erro ? (
        <>
          <Text style={styles.texto}>
            Não foi possível carregar os dados. Verifique a conexão e tente novamente.
          </Text>
          <BotaoGrande texto="Tentar novamente" onPress={onTentarNovamente} />
        </>
      ) : (
        <ActivityIndicator size="large" color={cores.primaria} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    justifyContent: 'center',
    padding: espacos.margem,
    gap: espacos.entreCampos,
    backgroundColor: cores.fundo,
  },
  texto: {
    ...tipografia.corpo,
    color: cores.textoSecundario,
    textAlign: 'center',
  },
});
