import { Image, ScrollView, StyleSheet, View } from 'react-native';
import { Text } from 'react-native-paper';
import Cabecalho from '../components/Cabecalho';
import MenuNotificacoes from '../components/MenuNotificacoes';
import CartaoAtalho from '../components/CartaoAtalho';
import SecaoServicos from '../components/SecaoServicos';
import { servicosEsteticos, servicosVeterinarios } from '../config/dados';
import { cores, espacos, raios, tipografia } from '../config/theme';

// O próximo agendamento vem do AppNavigator (calculado com os agendamentos do Firebase; null se não houver)
export default function InicioScreen({ navigation, proximoAgendamento }) {

  function agendar(servico) {
    navigation.navigate('Agendar', { servico: servico.nome });
  }

  return (
    <View style={styles.tela}>
      <Cabecalho>
        <View style={styles.linhaTopo}>
          <View style={styles.marca}>
            <Image source={require('../../assets/favicon.png')} style={styles.logo} />
            <Text style={styles.textoMarca}>
              Pet<Text style={styles.textoMarcaDestaque}>Care</Text>
            </Text>
          </View>

          <MenuNotificacoes
            agendamento={proximoAgendamento}
            onAbrirAgendamento={() => navigation.navigate('Agendamentos')}
          />
        </View>

        <Text style={styles.saudacao}>Olá! Como podemos cuidar do seu pet hoje?</Text>
      </Cabecalho>

      <ScrollView contentContainerStyle={styles.conteudo} showsVerticalScrollIndicator={false}>
        <View style={[styles.blocoComMargem, styles.atalhos]}>
          <CartaoAtalho
            icone="plus"
            titulo="Cadastrar pet"
            onPress={() => navigation.navigate('MeusPets', { screen: 'CadastrarPet', initial: false })}
          />
          <CartaoAtalho
            icone="calendar-blank-outline"
            titulo="Ver agendamentos"
            onPress={() => navigation.navigate('Agendamentos')}
          />
        </View>

        <SecaoServicos titulo="Serviços estéticos" servicos={servicosEsteticos} onAgendar={agendar} />

        <SecaoServicos
          titulo="Serviços veterinários"
          servicos={servicosVeterinarios}
          veterinario
          onAgendar={agendar}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    backgroundColor: cores.fundo,
  },
  linhaTopo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  marca: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: cores.superficie,
    borderRadius: raios.pilula,
    paddingLeft: 6,
    paddingRight: 14,
    paddingVertical: 5,
    marginTop: 12
  },
  logo: {
    width: 28,
    height: 28,
  },
  textoMarca: {
    ...tipografia.marca,
    color: cores.texto,
  },
  textoMarcaDestaque: {
    color: cores.primaria,
  },
  saudacao: {
    ...tipografia.saudacao,
    color: cores.superficie,
  },
  conteudo: {
    paddingTop: 12,
    paddingBottom: espacos.margem,
    gap: espacos.entreBlocos,
  },
  blocoComMargem: {
    marginHorizontal: espacos.margem,
  },
  atalhos: {
    flexDirection: 'row',
    gap: espacos.entreCards,
  },
});
